myfile = open('test.txt', 'r')

file_lines = myfile.readlines()
print len(file_lines)
